package com.example.salmanmapkar.demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class alttimetable extends AppCompatActivity {

    Spinner spinner_sem;
    Spinner spinner_branch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alttimetable);
        spinner_sem = (Spinner) findViewById(R.id.semester);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(alttimetable.this,android.R.layout.simple_spinner_item,getResources().getStringArray(R.array.semesters));
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_sem.setAdapter(adapter1);
        spinner_sem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(alttimetable.this, "SELECTED", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinner_branch = (Spinner) findViewById(R.id.branch);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(alttimetable.this,android.R.layout.simple_spinner_item,getResources().getStringArray(R.array.branch));
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_branch.setAdapter(adapter2);
        spinner_branch.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int j, long l) {
                Toast.makeText(alttimetable.this, "SELECTED", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}
